#ifndef FUNCIONALIDADES
#define _FUNCIONALIDADES_ FUNCIONALIDADES

	int funcao4(FILE *dados, FILE *indice);
	int funcao5(FILE *dados, FILE *indice, int n);
	int funcao6(FILE *dados, FILE *indice, int n);

#endif