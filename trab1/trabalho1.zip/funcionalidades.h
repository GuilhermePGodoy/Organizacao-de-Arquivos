#ifndef FUNCIONALIDADES
#define _FUNCIONALIDADES_ FUNCIONALIDADES

	int funcao4(FILE *dados, FILE *indice);
	void funcao5(FILE *dados, FILE *indice);
	void funcao6(FILE *dados, FILE *indice);

#endif