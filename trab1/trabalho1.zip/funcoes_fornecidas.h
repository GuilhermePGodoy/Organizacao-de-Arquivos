#ifndef _FUNCOES_FORNECIDAS_
#define FUNCOES_FORNECIDAS

	#include <stdio.h>
	#include <stdlib.h>
	#include <stddef.h>
	#include <ctype.h>
	#include <string.h>

	void binarioNaTela(char *nomeArquivoBinario);
	void scan_quote_string(char *str);

#endif