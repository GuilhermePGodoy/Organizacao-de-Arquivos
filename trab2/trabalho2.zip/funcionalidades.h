#ifndef FUNCIONALIDADES
	#define _FUNCIONALIDADES_ FUNCIONALIDADES

	int funcao7(FILE *dados, FILE *arvB);
	int funcao8(FILE *dados,  FILE *arvB, int n);
	int funcao9(FILE *dados,  FILE *arvB, int n);
	int funcao10(FILE *dados, FILE *arvB, int nroInsercoes);

#endif